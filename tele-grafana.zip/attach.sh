#!/bin/bash
docker exec -it grafana /bin/bash
